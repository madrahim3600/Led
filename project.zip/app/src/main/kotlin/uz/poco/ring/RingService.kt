package uz.poco.ring

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class RingService : Service() {
    companion object {
        @Volatile var inst: RingService? = null
        fun pulse() { inst?.pulse() }
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var cfg: Cfg
    private lateinit var drv: NotifDriver
    private lateinit var wl: PowerManager.WakeLock
    private lateinit var cm: CameraManager
    private var step = 0
    @Volatile private var until = 0L
    private val busy = HashSet<String>()

    private val camCb = object : CameraManager.AvailabilityCallback() {
        override fun onCameraUnavailable(id: String) { busy.add(id) }
        override fun onCameraAvailable(id: String) { busy.remove(id) }
    }

    private val tick = object : Runnable {
        override fun run() {
            val mode = cfg.i("mode", 0)
            val anim = cfg.i("anim", 0)
            val on = when (mode) {
                0 -> true
                1, 2 -> System.currentTimeMillis() < until
                else -> busy.isNotEmpty()
            }
            if (mode == 1 && !on) {
                cfg.put("on", 0)
                stopSelf()
                return
            }
            if (on) {
                if (!wl.isHeld) wl.acquire()
                val mask = cfg.i("mask", 1)
                val cols = (0..7).filter { ((mask shr it) and 1) == 1 }.ifEmpty { listOf(0) }
                drv.show(frame(step++, anim, cols))
            } else {
                if (wl.isHeld) wl.release()
                drv.off()
            }
            h.postDelayed(this, if (on && anim != 0) cfg.i("speed", 500).toLong() else 500L)
        }
    }

    fun pulse() { until = System.currentTimeMillis() + cfg.i("secs", 30) * 1000L }

    override fun onCreate() {
        super.onCreate()
        inst = this
        cfg = Cfg(this)
        drv = NotifDriver(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("svc", "Xizmat", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "svc")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("RGB halqa ishlayapti")
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        cm = getSystemService(CameraManager::class.java)
        cm.registerAvailabilityCallback(camCb, h)
        wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ring:wl")
        h.post(tick)
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (cfg.i("mode", 0) == 1) pulse()
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        cm.unregisterAvailabilityCallback(camCb)
        drv.off()
        if (wl.isHeld) wl.release()
        inst = null
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}

class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != packageName && !sbn.isOngoing) RingService.pulse()
    }
}

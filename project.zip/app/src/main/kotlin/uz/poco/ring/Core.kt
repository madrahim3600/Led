package uz.poco.ring

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

val PALETTE = intArrayOf(
    0xFFFF0000.toInt(), 0xFF00FF00.toInt(), 0xFF0000FF.toInt(), 0xFFFFFF00.toInt(),
    0xFF00FFFF.toInt(), 0xFFFF00FF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF8000.toInt()
)
val NAMES = arrayOf("Qizil", "Yashil", "Ko'k", "Sariq", "Firuza", "Binafsha", "Oq", "To'q sariq")
val MODES = arrayOf("Doimiy yoqish", "Vaqtincha yoqish", "Bildirishnoma kelganda", "Kamera ishlaganda")
val ANIMS = arrayOf("Doimiy", "Miltillash", "Ranglar almashishi", "Soatdek aylanish", "Kamalak")

class Cfg(c: Context) {
    private val p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun i(k: String, d: Int): Int = p.getInt(k, d)
    fun put(k: String, v: Int) { p.edit().putInt(k, v).apply() }
}

/** 4 segment: har biri PALETTE indeksi yoki -1 (o'chiq). Segmentlar soat yo'nalishida deb olinadi. */
fun frame(step: Int, anim: Int, cols: List<Int>): IntArray {
    val n = cols.size
    return when (anim) {
        1 -> IntArray(4) { if (step % 2 == 0) cols[(step / 2) % n] else -1 }
        2 -> IntArray(4) { cols[step % n] }
        3 -> IntArray(4) { if (it == step % 4) cols[(step / 4) % n] else -1 }
        4 -> IntArray(4) { (step + it) % 8 }
        else -> IntArray(4) { cols[0] }
    }
}

/** Standart Android bildirishnoma-LED kanali orqali (Xiaomi halqaga ulagan bo'lsagina ishlaydi). */
class NotifDriver(private val c: Context) {
    private val nm = c.getSystemService(NotificationManager::class.java)
    private var last = -2

    init {
        for (i in 0..7) {
            val ch = NotificationChannel("led$i", "RGB " + NAMES[i], NotificationManager.IMPORTANCE_DEFAULT)
            ch.enableLights(true)
            ch.lightColor = PALETTE[i]
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
        }
    }

    fun show(seg: IntArray) {
        val v = seg[0]
        if (v == last) return
        last = v
        nm.cancel(7)
        if (v >= 0) {
            nm.notify(
                7,
                Notification.Builder(c, "led$v")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("RGB " + NAMES[v])
                    .build()
            )
        }
    }

    fun off() {
        last = -2
        nm.cancel(7)
    }
}

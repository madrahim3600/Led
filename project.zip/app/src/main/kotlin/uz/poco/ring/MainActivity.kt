package uz.poco.ring

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var cfg: Cfg

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun snap(): Map<String, String> {
        val m = HashMap<String, String>()
        for (u in listOf(Settings.System.CONTENT_URI, Settings.Secure.CONTENT_URI, Settings.Global.CONTENT_URI)) {
            try {
                contentResolver.query(u, arrayOf("name", "value"), null, null, null)?.use { c ->
                    while (c.moveToNext()) m["${u.lastPathSegment}/${c.getString(0)}"] = c.getString(1) ?: ""
                }
            } catch (e: Exception) { }
        }
        return m
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cfg = Cfg(this)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(32), dp(16), dp(24))
        setContentView(ScrollView(this).apply { addView(root) })

        fun label(t: String) = root.addView(TextView(this).apply {
            text = t; textSize = 16f; setPadding(0, dp(16), 0, dp(4))
        })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply {
            text = t; setOnClickListener { f() }
        })
        fun spinner(items: Array<String>, key: String) = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(cfg.i(key, 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { cfg.put(key, pos) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        fun seek(lo: Int, hi: Int, key: String, def: Int) = SeekBar(this).apply {
            this.max = hi - lo
            progress = cfg.i(key, def) - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { cfg.put(key, p + lo) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        val svc = Intent(this, RingService::class.java)
        root.addView(Switch(this).apply {
            text = "RGB halqani yoqish"; textSize = 20f
            isChecked = cfg.i("on", 0) == 1
            setOnCheckedChangeListener { _, on ->
                cfg.put("on", if (on) 1 else 0)
                if (on) startForegroundService(svc) else stopService(svc)
            }
        })

        label("Rejim")
        root.addView(spinner(MODES, "mode"))
        label("Davomiylik (soniya) — vaqtincha va bildirishnoma rejimi uchun")
        root.addView(seek(5, 300, "secs", 30))

        label("Ranglar (bir nechtasini tanlasangiz, almashib yonadi)")
        val row = LinearLayout(this)
        for (i in 0..7) row.addView(Button(this).apply {
            setBackgroundColor(PALETTE[i])
            minWidth = 0; minimumWidth = 0
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
            fun paint() { alpha = if (((cfg.i("mask", 1) shr i) and 1) == 1) 1f else 0.25f }
            paint()
            setOnClickListener { cfg.put("mask", cfg.i("mask", 1) xor (1 shl i)); paint() }
        })
        root.addView(row)

        label("Animatsiya")
        root.addView(spinner(ANIMS, "anim"))
        label("Tezlik (chapga — tezroq)")
        root.addView(seek(120, 2000, "speed", 500))

        label("Ruxsatlar")
        btn("Bildirishnomalarni o'qish ruxsati") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("Batareya cheklovini o'chirish") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }

        label("Diagnostika (halqa ishlamasa)")
        var snapA: Map<String, String>? = null
        btn("1) Holatni saqlash") {
            snapA = snap()
            Toast.makeText(this, "Saqlandi. Tizim RGB sozlamasini o'zgartirib qaytib keling", Toast.LENGTH_LONG).show()
        }
        btn("2) Farqni ko'rsatish") {
            val a = snapA
            if (a == null) {
                Toast.makeText(this, "Avval 1-tugmani bosing", Toast.LENGTH_SHORT).show()
            } else {
                val d = snap().filter { (k, v) -> a[k] != v }
                    .map { (k, v) -> "$k: ${a[k]} -> $v" }
                    .joinToString("\n").ifEmpty { "Farq topilmadi" }
                AlertDialog.Builder(this).setTitle("O'zgargan sozlamalar").setMessage(d)
                    .setPositiveButton("Nusxalash") { _, _ ->
                        (getSystemService(ClipboardManager::class.java)).setPrimaryClip(ClipData.newPlainText("diff", d))
                    }
                    .setNegativeButton("Yopish", null).show()
            }
        }
    }
}
